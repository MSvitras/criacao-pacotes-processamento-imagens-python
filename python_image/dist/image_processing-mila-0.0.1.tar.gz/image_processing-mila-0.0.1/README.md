# image processing

Description
The package image_processing is used to:
    Processing:
    - Histogram matching
    - Structural similary
    - Resize Image
Utils:
    - Read image
    - Save image
    - Plot image
    - Plot result
    - Plot histogram

# Installation

Use the package manager [pip](http://pip.pypa.io/en/stable/) to install package_name

'''bach
pip install image_processing
'''

# Author
Milena Svitras

# Licence